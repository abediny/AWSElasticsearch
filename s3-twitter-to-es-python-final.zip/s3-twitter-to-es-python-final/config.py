
'''
Created on 26-12-2018

@author: Adam Abedini (a.abediny@gmail.com)
'''

es_host = 'search-twitterfeed-exsczg6i3gbo3znwxquow2zzqa.ap-southeast-2.es.amazonaws.com' #without the https - for example: search-es-twitter-demo-xxxxxxxxxxxxxxxxxxx.us-east-1-.es.amazonaws.com
es_port = 80
es_bulk_chunk_size = 1000  #number of documents to index in a single bulk operation

